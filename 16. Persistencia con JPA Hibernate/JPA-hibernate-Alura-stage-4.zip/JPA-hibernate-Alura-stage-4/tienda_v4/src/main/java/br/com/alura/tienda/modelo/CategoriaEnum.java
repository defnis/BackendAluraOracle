package br.com.alura.tienda.modelo;

public enum CategoriaEnum {

	CELULARES,
	SOFTWARES,
	LIBROS
}
