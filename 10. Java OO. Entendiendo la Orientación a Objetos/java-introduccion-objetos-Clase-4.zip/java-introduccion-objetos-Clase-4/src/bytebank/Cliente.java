package bytebank;

public class Cliente {

    String nombre;
    String documento;
    String telefono;

}
