package bytebank;

public class Cuenta {

    double saldo;
    int agencia;
    int numero;
    String titular;

}
