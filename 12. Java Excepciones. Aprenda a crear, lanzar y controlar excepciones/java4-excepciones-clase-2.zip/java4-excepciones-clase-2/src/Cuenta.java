
public class Cuenta {

	void deposita() {
		
	}
	
}
