
public class MiException extends Exception {

	public MiException() {
		super();
	}
	
	public MiException(String message) {
		super(message);
	}
	
}
