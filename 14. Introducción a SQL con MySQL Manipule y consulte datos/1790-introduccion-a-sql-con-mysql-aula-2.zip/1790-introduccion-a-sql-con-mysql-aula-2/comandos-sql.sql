# En esta aula te hablaremos sobre la historia de SQL y de My SQL.
# También instalaremos Workbench para poder utilizar un IDE en el desarrollo de nuestros ejercicios.

# Ya tu ambiente debe estar listo para trabajar. Te invito ver los videos y a ejecutar todos los 
# comandos que vas a aprender.
